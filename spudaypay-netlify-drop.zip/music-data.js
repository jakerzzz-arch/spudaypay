// 100% Genuine Full-Length Studio Tracks (Verified & Embeddable) for Spudaypay
const CURATED_TRACKS = [
  {
    "id": "track-1",
    "title": "Die With A Smile",
    "artist": "Lady Gaga, Bruno Mars",
    "album": "Die With A Smile",
    "genre": "pop",
    "category": "tophits",
    "duration": 252,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music221/v4/11/ae/f2/11aef294-f57c-bab9-c9fc-529162984e62/24UMGIM85348.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/07/6a/99/076a99ed-b946-431b-6f1f-54fa187ca5bd/mzaf_8102882277995122875.plus.aac.p.m4a",
    "ytVideoId": "kPa7bsKwL-c",
    "ytCandidateIds": [
      "PfH7jq_uSCM",
      "zgaCZOQCpp8",
      "2Py-vVdF0is",
      "1--pwdu-eJE"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-2",
    "title": "Espresso",
    "artist": "Sabrina Carpenter",
    "album": "Short n' Sweet",
    "genre": "pop",
    "category": "tophits",
    "duration": 175,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music211/v4/57/e8/7b/57e87ba0-5057-9bb9-c247-ce7dbe426e89/24UMGIM55213.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/e9/4d/02/e94d0230-11ee-ef94-d2cf-a5d547bd73f4/mzaf_554140808559155562.plus.aac.p.m4a",
    "ytVideoId": "51zjlMhdSTE",
    "ytCandidateIds": [
      "aB86Ub8dubQ",
      "4h0a1NCeC14",
      "eVli-tstM5E",
      "DKB-1EV5qHw"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-3",
    "title": "BIRDS OF A FEATHER",
    "artist": "Billie Eilish",
    "album": "HIT ME HARD AND SOFT",
    "genre": "pop",
    "category": "tophits",
    "duration": 210,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music211/v4/92/9f/69/929f69f1-9977-3a44-d674-11f70c852d1b/24UMGIM36186.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/34/31/d3/3431d34e-847f-5d66-df83-0bce688d997e/mzaf_18106743962423782018.plus.aac.p.m4a",
    "ytVideoId": "d5gf9dXbPi0",
    "ytCandidateIds": [
      "ZFUANtR97L0",
      "V9PVRfjEBTI",
      "geKxhmZL8ao",
      "YH6HJb_F-LE"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-4",
    "title": "Taste",
    "artist": "Sabrina Carpenter",
    "album": "Short n' Sweet",
    "genre": "pop",
    "category": "tophits",
    "duration": 157,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music221/v4/f6/15/d0/f615d0ab-e0c4-575d-907e-1cc084642357/24UMGIM61704.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/26/57/a6/2657a620-c596-e0e4-efa2-e814f3572d1c/mzaf_5475540510703120797.plus.aac.p.m4a",
    "ytVideoId": "hJEIA4OydoY",
    "ytCandidateIds": [
      "z9Q9OzL_wI8",
      "KEG7b851Ric",
      "IZCApBi_4jE",
      "cWK_rzPDVaU"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-5",
    "title": "Beautiful Things",
    "artist": "Benson Boone",
    "album": "Fireworks & Rollerblades",
    "genre": "pop",
    "category": "tophits",
    "duration": 180,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/54/f4/92/54f49210-e260-b519-ebbd-f4f40ee710cd/054391342751.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/4d/d5/00/4dd5006f-ee02-c3f1-94db-0ed4b8dd68f1/mzaf_14250561294796027079.plus.aac.p.m4a",
    "ytVideoId": "QcgPEv2BIpE",
    "ytCandidateIds": [
      "Oa_RSwwpPaA",
      "qKOMEWKrvb4",
      "PAl0KhPsUNw",
      "HU08BcK5SUY"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-6",
    "title": "Lose Control",
    "artist": "Teddy Swims",
    "album": "I've Tried Everything But Therapy",
    "genre": "pop",
    "category": "tophits",
    "duration": 211,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music126/v4/36/19/66/36196640-1561-dc5e-c6bc-1e5f4befa583/093624856771.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/9f/65/d6/9f65d67d-db40-d7da-c954-9a23d28dfe1a/mzaf_7625794503195542708.plus.aac.p.m4a",
    "ytVideoId": "FkOpwodhROI",
    "ytCandidateIds": [
      "QvvhiIevsX8",
      "2IByir-sh5k",
      "9gWIIIr2Asw",
      "mOAy_vCa33E"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-7",
    "title": "Good Luck, Babe!",
    "artist": "Chappell Roan",
    "album": "Good Luck, Babe!",
    "genre": "pop",
    "category": "tophits",
    "duration": 218,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music221/v4/29/a7/c4/29a7c478-351d-25eb-a116-3e68118cdab8/24UMGIM31246.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/c3/6d/4f/c36d4f23-b87f-046d-7a0e-e3e05d180b2a/mzaf_17235999651335214399.plus.aac.p.m4a",
    "ytVideoId": "1RKqOmSkGgM",
    "ytCandidateIds": [
      "xCh1T6fcRo8",
      "1GWelFUmOng",
      "DATxwI_5x2A",
      "u4H-Zconvlw"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-8",
    "title": "Please Please Please",
    "artist": "Sabrina Carpenter",
    "album": "Short n' Sweet",
    "genre": "pop",
    "category": "tophits",
    "duration": 184,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music221/v4/c9/a3/e9/c9a3e987-3952-a6ac-7975-680f2033e660/25UMGIM10586.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/54/86/0b/54860b8b-0c3b-b16b-5b19-b00424af8b9b/mzaf_1272478887800630516.plus.aac.p.m4a",
    "ytVideoId": "Yl_thbk40A0",
    "ytCandidateIds": [
      "zAgVtzhjfCA",
      "v_HQJDHF5rc",
      "cF1Na4AIecM",
      "aN2739fiLh4"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-9",
    "title": "Too Sweet",
    "artist": "Hozier",
    "album": "Unheard",
    "genre": "pop",
    "category": "tophits",
    "duration": 251,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music211/v4/98/80/95/98809581-4a0e-68a6-04de-b72492e35939/196871908191.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/a6/61/fc/a661fcaf-f8e5-03db-36f3-31f2e196b1a5/mzaf_18300083713037280538.plus.aac.p.m4a",
    "ytVideoId": "aezstCBHOPQ",
    "ytCandidateIds": [
      "L4id1prQooo",
      "sTO38qjOs-Y",
      "NTpbbQUBbuo",
      "uheV45iXhrI"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-10",
    "title": "I Had Some Help",
    "artist": "Post Malone, Morgan Wallen",
    "album": "F-1 Trillion",
    "genre": "pop",
    "category": "tophits",
    "duration": 178,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music211/v4/84/df/b9/84dfb96b-27c8-4d40-4780-b65ff22790e4/24UMGIM50612.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/1f/70/04/1f7004b7-414e-a89c-0148-abdd38981be8/mzaf_10246855408392712577.plus.aac.p.m4a",
    "ytVideoId": "4QIZE708gJ4",
    "ytCandidateIds": [
      "8gjBzdG6ifM",
      "PCBZOSM8h5U",
      "11T6kF66dKY",
      "AAPGi-WzN3M"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-11",
    "title": "we can't be friends",
    "artist": "Ariana Grande",
    "album": "eternal sunshine",
    "genre": "pop",
    "category": "tophits",
    "duration": 229,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music112/v4/2e/88/88/2e8888ad-a0cf-eece-70a7-1ff81377a3ab/24UMGIM00198.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/63/f1/45/63f1452d-5087-18b1-4426-52cd1f10bc06/mzaf_5211000209678891014.plus.aac.p.m4a",
    "ytVideoId": "UdRAXWNvjzE",
    "ytCandidateIds": [
      "DhK0fZ_hs04",
      "xVDgcLUeTis",
      "2gbo-KMXRPs",
      "KNtJGQkC-WI"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-12",
    "title": "Greedy",
    "artist": "Tate McRae",
    "album": "THINK LATER",
    "genre": "pop",
    "category": "tophits",
    "duration": 130,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/21/4a/c2/214ac20c-a66c-84a1-e357-f7e60b1932ca/196871542661.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/8d/e0/e2/8de0e2ae-f88c-5056-c07d-fe04acbc1d58/mzaf_1974309867621262359.plus.aac.p.m4a",
    "ytVideoId": "8AtiHCDGZ8c",
    "ytCandidateIds": [
      "UTmZqY_arzk",
      "lXrqsZ2lRNY",
      "1K_--gz5jhY",
      "To4SWGZkEPk"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-13",
    "title": "Houdini",
    "artist": "Dua Lipa",
    "album": "Radical Optimism",
    "genre": "pop",
    "category": "tophits",
    "duration": 186,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/dd/af/ea/ddafeab5-797a-5b6f-7735-f96c537b45e0/5054197894091.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/2c/da/b5/2cdab5c6-04a8-5231-c697-00101e876479/mzaf_5586859405346659517.plus.aac.p.m4a",
    "ytVideoId": "YIvwCIwDQT8",
    "ytCandidateIds": [
      "_-KzVRK5hng",
      "0C1p6v20Y9A",
      "Jq-Mrc5WCtQ",
      "jBcYMGcT2LA"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-14",
    "title": "Lovin On Me",
    "artist": "Jack Harlow",
    "album": "Lovin On Me",
    "genre": "hiphop",
    "category": "tophits",
    "duration": 138,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music126/v4/60/88/3e/60883eee-7ec2-75e9-ccc6-5a6187371d97/075679665010.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/f4/6e/5a/f46e5aab-e970-1b1d-c0a3-473808a0e265/mzaf_9582060488473069126.plus.aac.p.m4a",
    "ytVideoId": "VJA43ZH4-Ak",
    "ytCandidateIds": [
      "Iq8h3GEe22o",
      "ipfMwqHWSS4",
      "jC7277U411Q",
      "ogEeYttq9gU"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-15",
    "title": "Cruel Summer",
    "artist": "Taylor Swift",
    "album": "Lover",
    "genre": "pop",
    "category": "tophits",
    "duration": 178,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/49/3d/ab/493dab54-f920-9043-6181-80993b8116c9/19UMGIM53909.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/44/af/81/44af8168-9609-1b85-5048-ada08dceacf3/mzaf_1341699644335558812.plus.aac.p.m4a",
    "ytVideoId": "ic8j13piAhQ",
    "ytCandidateIds": [
      "MUwE5OfLFjw",
      "9rCVlaTXe40",
      "JLJcHbYSlB8",
      "P8T1rUpVdXE"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-16",
    "title": "Paint The Town Red",
    "artist": "Doja Cat",
    "album": "Scarlet",
    "genre": "hiphop",
    "category": "tophits",
    "duration": 232,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music126/v4/05/a1/62/05a162ca-d0f8-462a-a033-474a019e506f/196871274111.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/d5/3e/52/d53e52e6-8b99-ed81-59f4-7496f18e80cb/mzaf_16754470647437213840.plus.aac.p.m4a",
    "ytVideoId": "fGe8drSjqHI",
    "ytCandidateIds": [
      "kzMNOf8btMo",
      "Mf7FI9ltsSs",
      "TQQcOz49oks",
      "UBitESmuQfk"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-17",
    "title": "Water",
    "artist": "Tyla",
    "album": "TYLA",
    "genre": "pop",
    "category": "tophits",
    "duration": 200,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music126/v4/1e/c9/5b/1ec95bbc-a56f-cbef-070c-ddec9f4fdd3c/196871296205.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/9a/62/e6/9a62e688-9080-feed-2411-cc793c4545cf/mzaf_4449175929344535361.plus.aac.p.m4a",
    "ytVideoId": "wlmUnWLaeog",
    "ytCandidateIds": [
      "TSsFB241BHs",
      "1zNmYAp5xUw",
      "PBAMcKXcBKE",
      "AyvOF3m_EC8"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-18",
    "title": "Strangers",
    "artist": "Kenya Grace",
    "album": "The After Thought",
    "genre": "pop",
    "category": "tophits",
    "duration": 173,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/82/da/f7/82daf7a1-4d0e-9a94-9314-0916e4ab5635/054391385239.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/76/be/6e/76be6e54-2413-1411-7563-1e52a63ac767/mzaf_4464148852433554469.plus.aac.p.m4a",
    "ytVideoId": "S2TaAcwC_zI",
    "ytCandidateIds": [
      "RnyPNdBWwVw",
      "hPlikUUZ5RM",
      "NoMYZJ4j8xQ",
      "Nvm50gMVinc"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-19",
    "title": "Seven",
    "artist": "Jung Kook, Latto",
    "album": "GOLDEN",
    "genre": "pop",
    "category": "tophits",
    "duration": 184,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music126/v4/f2/54/08/f254081d-c7e2-6cd6-f7c5-dedb56fd95bd/196922710582_Cover.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/8f/bd/6f/8fbd6fd2-627d-eef7-0068-ab13f6aca958/mzaf_7711872023329437557.plus.aac.p.m4a",
    "ytVideoId": "lToqrE5Ludo",
    "ytCandidateIds": [
      "Vs64cZbeY88",
      "1QYBiNRu1ok",
      "XS48lWkH84Q",
      "QU9c0053UAU"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-20",
    "title": "vampire",
    "artist": "Olivia Rodrigo",
    "album": "GUTS",
    "genre": "pop",
    "category": "tophits",
    "duration": 220,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music221/v4/08/9e/07/089e0799-b405-9e69-b648-e6a19df9879c/24UMGIM30485.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/83/09/5e/83095ea1-83bf-ecdc-3b75-358c350fca51/mzaf_15560849688086702972.plus.aac.p.m4a",
    "ytVideoId": "Fqey8LxQxFU",
    "ytCandidateIds": [
      "QXsZ4zeSvwo",
      "iJ9Ho-3oH5Y",
      "RXdABv5O4qc",
      "RlPNh_PBZb4"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-21",
    "title": "Blinding Lights",
    "artist": "The Weeknd",
    "album": "After Hours",
    "genre": "synthwave",
    "category": "charts",
    "duration": 216,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/61/e7/3f/61e73f94-018d-5f50-50ec-8521952bc72e/20UM1IM11629.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/12/73/ca/1273ca46-233a-5331-189b-25ac1d656533/mzaf_976341070785891411.plus.aac.p.m4a",
    "ytVideoId": "BwX8OS4cegU",
    "ytCandidateIds": [
      "4NRXx6U8ABQ",
      "8E0GXu9d0tk",
      "fHI8X4OXluQ",
      "57__wGDUzig"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-22",
    "title": "Shape of You",
    "artist": "Ed Sheeran",
    "album": "Divide",
    "genre": "pop",
    "category": "charts",
    "duration": 234,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/15/e6/e8/15e6e8a4-4190-6a8b-86c3-ab4a51b88288/190295851286.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/44/c7/4f/44c74f0d-72dc-6143-d4d0-ba14d661ca0d/mzaf_9566898362556366703.plus.aac.p.m4a",
    "ytVideoId": "_dK2tDK9grQ",
    "ytCandidateIds": [
      "nQrwTHTfhto",
      "liTfD88dbCo",
      "JGwWNGJdvx8",
      "fXJ4ZVfyfMA"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-23",
    "title": "Someone You Loved",
    "artist": "Lewis Capaldi",
    "album": "Divinely Uninspired",
    "genre": "pop",
    "category": "charts",
    "duration": 182,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/92/d7/8f/92d78fb1-df3d-049e-c81d-7022808b151f/19UMGIM02973.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/e5/c8/17/e5c817e2-7830-091f-8686-d6276d5beaeb/mzaf_5586826958480073790.plus.aac.p.m4a",
    "ytVideoId": "zABLecsR5UE",
    "ytCandidateIds": [
      "xrcMgO2fgpA",
      "FGGo8LFmbjs",
      "lJVpE71Zwa4",
      "AyCrypt1pdI"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-24",
    "title": "Sunflower",
    "artist": "Post Malone, Swae Lee",
    "album": "Spider-Man: Into the Spider-Verse",
    "genre": "lofi",
    "category": "charts",
    "duration": 158,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/4b/30/2c/4b302cb6-7a14-5464-4e97-0577e9d0be49/18UMGIM82277.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/98/f0/d6/98f0d67e-f8bf-762d-cac7-1c6b3b6b35dd/mzaf_4543283896248560946.plus.aac.p.m4a",
    "ytVideoId": "ApXoWvfEYVU",
    "ytCandidateIds": [
      "2xRfeHRVF1I",
      "Dghmoi7XZmc",
      "1BJHeIIrMM8",
      "3E78T8h5EhA"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-25",
    "title": "Starboy",
    "artist": "The Weeknd, Daft Punk",
    "album": "Starboy",
    "genre": "synthwave",
    "category": "charts",
    "duration": 230,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/b5/92/bb/b592bb72-52e3-e756-9b26-9f56d08f47ab/16UMGIM67864.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/11/71/d6/1171d6ad-3c96-e027-2af6-58028426588c/mzaf_15137631797407745471.plus.aac.p.m4a",
    "ytVideoId": "Rif-RTvmmss",
    "ytCandidateIds": [
      "q-cKwdoa3X8",
      "plnfIj7dkJE",
      "xizN47Box_Y",
      "34Na4j8AVgA"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-26",
    "title": "As It Was",
    "artist": "Harry Styles",
    "album": "Harry's House",
    "genre": "pop",
    "category": "charts",
    "duration": 167,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music126/v4/2a/19/fb/2a19fb85-2f70-9e44-f2a9-82abe679b88e/886449990061.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/67/10/16/67101606-3869-ca44-6c03-e13d6322cb51/mzaf_1135399237022217274.plus.aac.p.m4a",
    "ytVideoId": "V1Z586zoeeE",
    "ytCandidateIds": [
      "CjIUVRei27g",
      "RWgPMFas1fo",
      "Qfm6nfz1QNQ",
      "H5v3kku4y6Q"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-27",
    "title": "Stay",
    "artist": "The Kid LAROI, Justin Bieber",
    "album": "F*CK LOVE 3",
    "genre": "pop",
    "category": "charts",
    "duration": 142,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/89/59/6a/89596ab9-fa3c-8d08-4d95-a6450fa2013c/886449400515.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/d7/4a/84/d74a84d5-9afa-761e-b632-baab55c2a23b/mzaf_11865500880477235553.plus.aac.p.m4a",
    "ytVideoId": "Qb8q4ijHk_M",
    "ytCandidateIds": [
      "rkYlZnIbe2E",
      "kTJczUoc26U",
      "yWHrYNP6j4k",
      "pd1_SxHh2vo"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-28",
    "title": "Heat Waves",
    "artist": "Glass Animals",
    "album": "Dreamland",
    "genre": "synthwave",
    "category": "charts",
    "duration": 239,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/da/8b/77/da8b7731-6f4f-eacf-5e74-8b23389eefa1/20UMGIM03371.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/a3/4c/b9/a34cb911-40fc-5f0c-e862-14bd171a77aa/mzaf_384792072030970151.plus.aac.p.m4a",
    "ytVideoId": "pzeefqfSMjY",
    "ytCandidateIds": [
      "KT7F15T9VBI",
      "WgiWUnJqy3k",
      "rfTgO9rpqck",
      "mRD0-GxqHVo"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-29",
    "title": "Levitating",
    "artist": "Dua Lipa",
    "album": "Future Nostalgia",
    "genre": "pop",
    "category": "charts",
    "duration": 204,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/6c/11/d6/6c11d681-aa3a-d59e-4c2e-f77e181026ab/190295092665.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/59/dc/4d/59dc4dda-93ff-8f1c-c536-f005f6ea6af5/mzaf_3066686759813252385.plus.aac.p.m4a",
    "ytVideoId": "WHuBW3qKm9g",
    "ytCandidateIds": [
      "G2nJPEDc02k",
      "TUVcZfQe-Kw",
      "PqbJJNuVMoc",
      "ovG2QwiObhk"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-30",
    "title": "Believer",
    "artist": "Imagine Dragons",
    "album": "Evolve",
    "genre": "rock",
    "category": "charts",
    "duration": 204,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music126/v4/11/7a/b8/117ab805-6811-8929-18b9-0fad7baf0c25/17UMGIM98210.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/c0/3f/36/c03f367a-b66b-fd0a-a54c-30f8250c4410/mzaf_12768434238801682952.plus.aac.p.m4a",
    "ytVideoId": "IhP3J0j9JmY",
    "ytCandidateIds": [
      "W0DM5lcj6mw",
      "BKVIyxQfrJc",
      "7sPaMKvoGbk",
      "7wtfhZwyrcc"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-31",
    "title": "Closer",
    "artist": "The Chainsmokers, Halsey",
    "album": "Collage",
    "genre": "pop",
    "category": "charts",
    "duration": 246,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/41/f8/38/41f8380b-9b56-d5d4-31f7-a6411c0c9aaa/886446102054.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/bd/f9/b9/bdf9b9b2-eaa4-4461-6079-aaacc6df7316/mzaf_17327312786932455493.plus.aac.p.m4a",
    "ytVideoId": "25ROFXjoaAU",
    "ytCandidateIds": [
      "U_ppsAcbZDo",
      "9yPKP2bLcDE",
      "PT2_F-1esPk",
      "6lwUIHzHJpk"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-32",
    "title": "Dance Monkey",
    "artist": "Tones And I",
    "album": "The Kids Are Coming",
    "genre": "pop",
    "category": "charts",
    "duration": 209,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/87/ed/42/87ed4279-d8d7-840f-90b5-2bffe34699ef/075679839237.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/43/1a/32/431a3203-7e62-c7b1-0377-824aded16096/mzaf_7471896698419931094.plus.aac.p.m4a",
    "ytVideoId": "uCGyra8VDY4",
    "ytCandidateIds": [
      "q0hyYWKXF0Q",
      "0Yy9YzdmTJA",
      "1__CAdTJ5JU",
      "4nsORR-kkOg"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-33",
    "title": "bad guy",
    "artist": "Billie Eilish",
    "album": "WHEN WE ALL FALL ASLEEP",
    "genre": "pop",
    "category": "charts",
    "duration": 194,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/1a/37/d1/1a37d1b1-8508-54f2-f541-bf4e437dda76/19UMGIM05028.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/c3/87/1f/c3871f7e-3260-d615-1c66-5fdca2c3a48f/mzaf_10721331211699880949.plus.aac.p.m4a",
    "ytVideoId": "YD4utuFiexw",
    "ytCandidateIds": [
      "DyDfgMOUjCI",
      "Hk9eBrkH7nY",
      "4-TbQnONe_w",
      "xpRxgwO00Kg"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-34",
    "title": "Perfect",
    "artist": "Ed Sheeran",
    "album": "Divide",
    "genre": "pop",
    "category": "charts",
    "duration": 263,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/15/e6/e8/15e6e8a4-4190-6a8b-86c3-ab4a51b88288/190295851286.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/c7/ba/bc/c7babc66-f598-aaa6-bcf6-307281795817/mzaf_16337361235117168274.plus.aac.p.m4a",
    "ytVideoId": "iKzRIweSBLA",
    "ytCandidateIds": [
      "CWG-GDfejmY",
      "2Vv-BfVoq4g",
      "cNGjD0VG4R8",
      "ixefTend7Tk"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-35",
    "title": "Watermelon Sugar",
    "artist": "Harry Styles",
    "album": "Fine Line",
    "genre": "pop",
    "category": "charts",
    "duration": 174,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/2b/c4/c9/2bc4c9d4-3bc6-ab13-3f71-df0b89b173de/886448022213.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/8d/2b/cf/8d2bcff6-d284-7c4e-d6e3-9d70d019236a/mzaf_13222308322329291378.plus.aac.p.m4a",
    "ytVideoId": "7-x3uD5z1bQ",
    "ytCandidateIds": [
      "dZwffaluIgg",
      "zuTr8iwp8Cw",
      "E07s5ZYygMg",
      "U-BckaiDf-M"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-36",
    "title": "Save Your Tears",
    "artist": "The Weeknd",
    "album": "After Hours",
    "genre": "synthwave",
    "category": "charts",
    "duration": 216,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music124/v4/83/3a/f7/833af71b-2e0c-3303-24f5-8f5c546c073b/20UMGIM21167.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/8b/38/17/8b3817e4-c0e9-7e02-2654-3e2ecee93603/mzaf_18415642125637540903.plus.aac.p.m4a",
    "ytVideoId": "u6lihZAcy4s",
    "ytCandidateIds": [
      "d_eAuvP52-c",
      "tEeK40cjmkw",
      "LIIDh-qI9oI",
      "vI9zLBFJ3LU"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-37",
    "title": "Shivers",
    "artist": "Ed Sheeran",
    "album": "Equals",
    "genre": "pop",
    "category": "charts",
    "duration": 208,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/c5/d8/c6/c5d8c675-63e3-6632-33db-2401eabe574d/190296491412.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/a8/9f/a5/a89fa5e9-8a3b-77bb-e081-866067d3f213/mzaf_13889707114574366771.plus.aac.p.m4a",
    "ytVideoId": "z2_Lrg6rRks",
    "ytCandidateIds": [
      "IddzbZpG4QM",
      "Il0S8BoucSA",
      "Nnl-qn3vlLU",
      "YaPZ0ii5Ai4"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-38",
    "title": "Lovely",
    "artist": "Billie Eilish, Khalid",
    "album": "13 Reasons Why",
    "genre": "pop",
    "category": "charts",
    "duration": 200,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/27/94/d4/2794d4fc-c3e2-2373-3e6c-dd82fd5aefe6/18UMGIM18200.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/1e/d8/8d/1ed88d91-fb06-b3f2-5391-afd732cc2ff9/mzaf_18444937225262929488.plus.aac.p.m4a",
    "ytVideoId": "V1Pl8CzNzCw",
    "ytCandidateIds": [
      "VF__8a8HaFc",
      "8VLXHyHRXjc",
      "wjj2upnfBI0",
      "e_UK2BHsS7M"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-39",
    "title": "Circles",
    "artist": "Post Malone",
    "album": "Hollywood's Bleeding",
    "genre": "pop",
    "category": "charts",
    "duration": 215,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/7b/1b/1b/7b1b1b0b-7ce2-b223-f9e0-8e36abe51877/19UMGIM78325.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/f9/b1/aa/f9b1aaed-3e24-227f-153d-99969f8b8464/mzaf_6272498007975402144.plus.aac.p.m4a",
    "ytVideoId": "pQV0WEdT_OE",
    "ytCandidateIds": [
      "wXhTHyIgQ_U",
      "TqXPtEU9MJs",
      "9gkRJONZPSA",
      "WnLIGgTaBM0"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-40",
    "title": "Lucid Dreams",
    "artist": "Juice WRLD",
    "album": "Goodbye & Good Riddance",
    "genre": "hiphop",
    "category": "charts",
    "duration": 240,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/75/9b/af/759baf5f-f3c9-b8c7-d3cf-55a3079914b9/18UMGIM24792.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/9c/cb/87/9ccb87b5-cfd0-a77c-94fb-fe6fa124bcef/mzaf_7202917834670087023.plus.aac.p.m4a",
    "ytVideoId": "onbC6N-QGPc",
    "ytCandidateIds": [
      "VTG-ForqDk4",
      "_fh64GbFSw4",
      "mzB1VGEGcSU",
      "7JGIMUEQ46k"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-41",
    "title": "Don't Start Now",
    "artist": "Dua Lipa",
    "album": "Future Nostalgia",
    "genre": "pop",
    "category": "pop",
    "duration": 183,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/41/ee/66/41ee66fa-f8dd-7e82-155a-3a1b360dc562/190295322175.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/24/3d/34/243d3413-a0fc-b229-f54a-1715ebd3a9ca/mzaf_11578996572221800393.plus.aac.p.m4a",
    "ytVideoId": "xjiYBGs0TUA",
    "ytCandidateIds": [
      "Jepx-Wm_f04",
      "oygrmJFKYZY",
      "LcrahEiFuUM",
      "8CLkVWB_Lj8"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-42",
    "title": "Calm Down",
    "artist": "Rema, Selena Gomez",
    "album": "Rave & Closes",
    "genre": "pop",
    "category": "pop",
    "duration": 220,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/b2/b4/7c/b2b47cf9-d8e2-53f6-5c62-c974d665c95b/22UMGIM08994.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/3c/7e/3b/3c7e3b1d-c005-91cb-51d1-2d86effd9990/mzaf_6788794088599474630.plus.aac.p.m4a",
    "ytVideoId": "WcIcVapfqXw",
    "ytCandidateIds": [
      "LPgN4EfzUrU",
      "035_8BcJPDk",
      "W50sgQV1pl0",
      "3fmGuw4eHmM"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-43",
    "title": "Anti-Hero",
    "artist": "Taylor Swift",
    "album": "Midnights",
    "genre": "pop",
    "category": "pop",
    "duration": 201,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music112/v4/3d/01/f2/3d01f2e5-5a08-835f-3d30-d031720b2b80/22UM1IM07364.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/1d/56/2a/1d562a07-dc5f-a9c0-1f36-2051a8c14eb7/mzaf_7214829135431340590.plus.aac.p.m4a",
    "ytVideoId": "XqN2qFvY64U",
    "ytCandidateIds": [
      "pGHK4UPCtXk",
      "b1kbLwvqugk",
      "N2ucWOw-v0c",
      "ADiogsXaZ-w"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-44",
    "title": "Flowers",
    "artist": "Miley Cyrus",
    "album": "Endless Summer Vacation",
    "genre": "pop",
    "category": "pop",
    "duration": 201,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music126/v4/8c/67/ff/8c67ff91-31c3-3fef-1884-ce3ec89f3af4/196589946874.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/68/9e/f7/689ef7fe-14fe-a846-c87f-7d3b2d6344b1/mzaf_4167137058064023087.plus.aac.p.m4a",
    "ytVideoId": "SWpAYbgHmTo",
    "ytCandidateIds": [
      "7V3jqsIe8c0",
      "nO8gpFd09fU",
      "G7KNmW9a75Y",
      "iawgB2CDCrw"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-45",
    "title": "One Kiss",
    "artist": "Calvin Harris, Dua Lipa",
    "album": "One Kiss",
    "genre": "pop",
    "category": "pop",
    "duration": 215,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music124/v4/91/2a/7b/912a7bdb-c2f6-b887-9392-49728fece0df/886447044360.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/33/81/fc/3381fc37-e216-04f3-2e61-a5ab7b9c79c3/mzaf_11986095118390090442.plus.aac.p.m4a",
    "ytVideoId": "V1gsO0wJX54",
    "ytCandidateIds": [
      "oCab3KiXveY",
      "DkeiKbqa02g",
      "Bm8rz-llMhE",
      "h8P-d0RV2Mk"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-46",
    "title": "Cold Heart",
    "artist": "Elton John, Dua Lipa, PNAU",
    "album": "The Lockdown Sessions",
    "genre": "pop",
    "category": "pop",
    "duration": 203,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/09/14/d4/0914d491-67ca-62fc-64a2-4bad5278b7ae/21UMGIM74865.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/cd/77/9a/cd779a0e-1763-24ec-a316-ef63be00f149/mzaf_15536077081789183929.plus.aac.p.m4a",
    "ytVideoId": "qod03PVTLqk",
    "ytCandidateIds": [
      "oGZ1PVwJyPQ",
      "PTOaTuGllyY",
      "2et2gPSR72U",
      "lImsPi5RGGo"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-47",
    "title": "Titanium",
    "artist": "David Guetta, Sia",
    "album": "Nothing but the Beat",
    "genre": "pop",
    "category": "pop",
    "duration": 245,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music114/v4/99/b4/7b/99b47bd8-2b22-e1ef-2e60-c5147f27a861/dj.thrvmjqj.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/45/dd/8f/45dd8ffc-0164-1f70-c53d-bf91a1d80b1a/mzaf_3092057092144618662.plus.aac.p.m4a",
    "ytVideoId": "Rohq0D72X3Q",
    "ytCandidateIds": [
      "P-gWGlf_VrY",
      "KxnpFKZowcs",
      "fGt3lDtozqM",
      "JRfuAukYTKg"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-48",
    "title": "Wake Me Up",
    "artist": "Avicii",
    "album": "True",
    "genre": "pop",
    "category": "pop",
    "duration": 250,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music211/v4/18/5b/1e/185b1ef5-5d97-19d8-aebf-8e29e41874ef/13UAAIM59255.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/68/1e/60/681e601f-e1f2-4ebb-37de-adf00bdf57b6/mzaf_8266263075137964740.plus.aac.p.m4a",
    "ytVideoId": "5y_KJAg8bHI",
    "ytCandidateIds": [
      "a3Klv0p2f74",
      "IcrbM1l_BoI",
      "BBP_GrLCY38",
      "fE96CxPls5A"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-49",
    "title": "Lean On",
    "artist": "Major Lazer, DJ Snake, MO",
    "album": "Peace Is The Mission",
    "genre": "pop",
    "category": "pop",
    "duration": 177,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/3a/9b/bd/3a9bbdba-5829-91c8-1349-cc04cdaf3423/653738030629_Cover.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/97/f0/20/97f02080-81c3-90a5-e45a-fb7b4e842dbb/mzaf_10164896606044573073.plus.aac.p.m4a",
    "ytVideoId": "rn9AQoI7mYU",
    "ytCandidateIds": [
      "YqeW9_5kURI",
      "T_i01_w7M6k",
      "xXIhxNYiWLI",
      "4ZxFyXV7w0c"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-50",
    "title": "Can't Stop The Feeling!",
    "artist": "Justin Timberlake",
    "album": "Trolls",
    "genre": "pop",
    "category": "pop",
    "duration": 238,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/68/19/43/68194388-efa7-3afe-8a15-a4c3eebef1f6/886445915211.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/86/41/2d/86412d20-2f4d-39fc-221b-3f643d7c99c6/mzaf_9909715182585785919.plus.aac.p.m4a",
    "ytVideoId": "KbyPok-3dio",
    "ytCandidateIds": [
      "ru0K8uYEZWw",
      "0Ui-QzihJGo",
      "YxRothF-QE4",
      "ShJV9F-mVfU"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-51",
    "title": "Uptown Funk",
    "artist": "Mark Ronson, Bruno Mars",
    "album": "Uptown Special",
    "genre": "pop",
    "category": "pop",
    "duration": 270,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/7e/30/c5/7e30c572-aa47-5f7b-c6fd-42d50cd2c56d/886444959797.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/91/99/1f/91991fe5-aa77-87e4-edbc-6d68c95e5f18/mzaf_10685317694850942114.plus.aac.p.m4a",
    "ytVideoId": "7Ya2U8XN_Zw",
    "ytCandidateIds": [
      "OPf0YbXqDm0",
      "i-FZAsWu-UI",
      "W8FUmkw3a4U",
      "O0l8i3Q3juE"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-52",
    "title": "Roar",
    "artist": "Katy Perry",
    "album": "PRISM",
    "genre": "pop",
    "category": "pop",
    "duration": 224,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music221/v4/36/21/81/36218129-51b4-df22-cafb-8e9503b53147/13UAAIM70445.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/21/a8/76/21a87607-1fe3-2bd2-753c-0b4b73c22b90/mzaf_9666996724668759977.plus.aac.p.m4a",
    "ytVideoId": "mwL1cohnHNE",
    "ytCandidateIds": [
      "oT73UO5nQXM",
      "zoJAcgmOS4Q",
      "CevxZvSJLk8",
      "bn3-c8CmZ5g"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-53",
    "title": "Shake It Off",
    "artist": "Taylor Swift",
    "album": "1989",
    "genre": "pop",
    "category": "pop",
    "duration": 219,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music221/v4/a7/98/d8/a798d867-344d-2bf2-fbfe-d2d1412dcef8/14UMDIM03793.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/11/d5/6d/11d56d4a-ce23-e793-8681-70dc4d35d931/mzaf_5886436202259848624.plus.aac.p.m4a",
    "ytVideoId": "H59xVMF4zxE",
    "ytCandidateIds": [
      "w9E7tRTkf5E",
      "k0TEcUm7lTk",
      "Z4A9ZZo_rAE",
      "9M-h3AthyMU"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-54",
    "title": "Cheap Thrills",
    "artist": "Sia",
    "album": "This Is Acting",
    "genre": "pop",
    "category": "pop",
    "duration": 212,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/bc/13/27/bc13275c-8b26-802d-771b-d15ae00fb530/mzm.hvpwjsvi.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/89/73/fb/8973fb2c-5417-e56b-30f1-bf5035bb46a2/mzaf_5922398524297774212.plus.aac.p.m4a",
    "ytVideoId": "J1b22l1kFKY",
    "ytCandidateIds": [
      "nEIHHydwec8",
      "mY9fNwGE7YA",
      "HbzZPpWr4MI",
      "nYh-n7EOtMA"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-55",
    "title": "Sugar",
    "artist": "Maroon 5",
    "album": "V",
    "genre": "pop",
    "category": "pop",
    "duration": 236,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music122/v4/b7/25/76/b72576f1-072e-3da2-60d5-2724a9bccf4a/14UMGIM31673.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/1b/3f/68/1b3f68e0-3c42-f367-cd0f-e46c746e0668/mzaf_15052021441666328650.plus.aac.p.m4a",
    "ytVideoId": "BNORkjGS_W0",
    "ytCandidateIds": [
      "GhH4rTap48M",
      "Y-pEoGvuWKk",
      "K-uEJtKJKIE",
      "Slnoeztfg68"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-56",
    "title": "The Hills",
    "artist": "The Weeknd",
    "album": "Beauty Behind the Madness",
    "genre": "hiphop",
    "category": "hiphop",
    "duration": 242,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music124/v4/30/05/1e/30051e57-a63a-3acc-4b30-42568293f5f7/15UMGIM36514.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/0b/70/c8/0b70c898-ec23-3131-5d17-aa7417045013/mzaf_3059117378996578649.plus.aac.p.m4a",
    "ytVideoId": "G5XpJP7f_SE",
    "ytCandidateIds": [
      "zxdSHfZFKkY",
      "yzTuBuRdAyA",
      "BhsgCT8u1Lk",
      "N8mBcZ05Q4w"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-57",
    "title": "God's Plan",
    "artist": "Drake",
    "album": "Scorpion",
    "genre": "hiphop",
    "category": "hiphop",
    "duration": 199,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/bb/6d/8f/bb6d8f67-6d04-10b5-dd62-eb5809ac54fc/00602567879152.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/c6/4a/be/c64abe74-adb4-cff5-005d-0fab3d72a806/mzaf_10276154697254415719.plus.aac.p.m4a",
    "ytVideoId": "m1a_GqJf02M",
    "ytCandidateIds": [
      "1gU-ELcGGqg",
      "xpVfcZ0ZcFM",
      "hxP74FKlA-Y",
      "J9XVincsyRU"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-58",
    "title": "SICKO MODE",
    "artist": "Travis Scott",
    "album": "ASTROWORLD",
    "genre": "hiphop",
    "category": "hiphop",
    "duration": 313,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/e7/49/8f/e7498f65-df8f-bead-d6e3-2a8d4d642a79/886447235317.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/d3/91/a1/d391a141-256f-726f-9da1-8aa4e42b3236/mzaf_17761183103753218003.plus.aac.p.m4a",
    "ytVideoId": "d-JBBNg8YKs",
    "ytCandidateIds": [
      "6ONRf7h3Mdk",
      "f2YWfeFRZO0",
      "hh8kmVjObRU",
      "HNMuFjl5FTo"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-59",
    "title": "goosebumps",
    "artist": "Travis Scott",
    "album": "Birds in the Trap",
    "genre": "hiphop",
    "category": "hiphop",
    "duration": 244,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music114/v4/b8/e5/27/b8e527c8-aaf4-c7b7-5562-c479458ed7d9/886446092645.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/f0/60/39/f060399b-690f-2e55-7013-5530cd616d95/mzaf_6001308391779304655.plus.aac.p.m4a",
    "ytVideoId": "Dst9gZkq1a8",
    "ytCandidateIds": [
      "_9XaXHD3680",
      "JfPpEif_HXE",
      "FhTtYSU7Q7g",
      "OljJ5gn86fk"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-60",
    "title": "rockstar",
    "artist": "Post Malone, 21 Savage",
    "album": "beerbongs & bentleys",
    "genre": "hiphop",
    "category": "hiphop",
    "duration": 218,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music124/v4/55/9f/fb/559ffb75-3c00-abd6-7b1f-8b6b1518b173/18UMGIM22101.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/22/37/94/223794d5-e415-e646-a1c6-a52f178f9c82/mzaf_4256851832513251175.plus.aac.p.m4a",
    "ytVideoId": "4GFAZBKZVJY",
    "ytCandidateIds": [
      "UceaB4D0jpo",
      "yJZY2qKsdPo",
      "iNyx2wJxoBI",
      "gI3Zn9-tuq8"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-61",
    "title": "Congratulations",
    "artist": "Post Malone, Quavo",
    "album": "Stoney",
    "genre": "hiphop",
    "category": "hiphop",
    "duration": 220,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music122/v4/94/09/25/9409251c-ea9e-040c-7649-52a66ac533ac/16UMGIM76041.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/34/42/13/344213e4-0001-702a-676c-2aa9a6d1d767/mzaf_493931479406269699.plus.aac.p.m4a",
    "ytVideoId": "R8vpQdZErbw",
    "ytCandidateIds": [
      "m_DG4shGECI",
      "SC4xMk98Pdc",
      "mtXjDa61_Fs",
      "XbuEoQ1cpfU"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-62",
    "title": "INDUSTRY BABY",
    "artist": "Lil Nas X, Jack Harlow",
    "album": "MONTERO",
    "genre": "hiphop",
    "category": "hiphop",
    "duration": 212,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/f7/16/67/f7166746-6299-5e54-8c7c-9535e941a53e/886449403929.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/51/97/7a/51977a71-448a-202a-5e60-756d5dcb6eeb/mzaf_194387576127428058.plus.aac.p.m4a",
    "ytVideoId": "i9PSG5mFYoo",
    "ytCandidateIds": [
      "HCq1OcAEAm0",
      "-SCoB_C7ICE",
      "hfoKlM2FTsI",
      "VkBf-TzS_Is"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-63",
    "title": "XO Tour Llif3",
    "artist": "Lil Uzi Vert",
    "album": "Luv Is Rage 2",
    "genre": "hiphop",
    "category": "hiphop",
    "duration": 183,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music211/v4/02/ed/6f/02ed6f77-7e89-ca9c-4d5a-83088113cbe8/075679887955.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/ff/be/8d/ffbe8d52-9942-858b-75e7-ef68b27da9c1/mzaf_16399358930097655830.plus.aac.p.m4a",
    "ytVideoId": "VcyFfcJbyeM",
    "ytCandidateIds": [
      "LoD-c5eEA38",
      "Yf0ORKcSsMs",
      "WrsFXgQk5UI",
      "wvqri9oS4G4"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-64",
    "title": "HUMBLE.",
    "artist": "Kendrick Lamar",
    "album": "DAMN.",
    "genre": "hiphop",
    "category": "hiphop",
    "duration": 177,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music112/v4/ab/16/ef/ab16efe9-e7f1-66ec-021c-5592a23f0f9e/17UMGIM88793.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/1f/2e/37/1f2e37be-bdd0-d770-6ea4-091011a6aade/mzaf_2360827885900940865.plus.aac.p.m4a",
    "ytVideoId": "wL_xmuij6lA",
    "ytCandidateIds": [
      "ov4WobPqoSA",
      "tvTRZJ-4EyI",
      "ZZxHN6hpoeQ",
      "jBvrQmtn4aQ"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-65",
    "title": "Money Trees",
    "artist": "Kendrick Lamar, Jay Rock",
    "album": "good kid, m.A.A.d city",
    "genre": "hiphop",
    "category": "hiphop",
    "duration": 387,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music122/v4/36/86/ec/3686ec99-dec4-0a01-8b74-2d8a9a0263a7/12UMGIM52988.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/be/7f/2f/be7f2fe2-41dd-6b9a-4957-a10ac5c62989/mzaf_17460900856492630846.plus.aac.p.m4a",
    "ytVideoId": "hwR_1EP18eo",
    "ytCandidateIds": [
      "Iy-dJwHVX84",
      "6TBeJjkwPXM",
      "tVyw9H2Iuyw",
      "HJNa9Ih3haA"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-66",
    "title": "Mask Off",
    "artist": "Future",
    "album": "FUTURE",
    "genre": "hiphop",
    "category": "hiphop",
    "duration": 181,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music127/v4/f9/10/59/f9105950-7370-e2ac-20b5-f82b9ccdc593/886446559476.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/57/21/c0/5721c05c-5439-8d80-9cf7-dc950c7802a1/mzaf_12494194571535032679.plus.aac.p.m4a",
    "ytVideoId": "-YVlgXN7spw",
    "ytCandidateIds": [
      "hGsnX_t1yKw",
      "xvZqHgFz51I",
      "fHafwr4OA0M",
      "1H18sl64l1s"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-67",
    "title": "Creepin'",
    "artist": "Metro Boomin, The Weeknd, 21 Savage",
    "album": "HEROES & VILLAINS",
    "genre": "hiphop",
    "category": "hiphop",
    "duration": 222,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music112/v4/82/f7/2b/82f72ba4-524c-fc9d-cb8c-5a96d2ddf536/22UM1IM35267.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/47/ba/83/47ba83bd-ff6a-d4b2-f126-545a170f0775/mzaf_2932236241939206370.plus.aac.p.m4a",
    "ytVideoId": "LOqGYF0oFIg",
    "ytCandidateIds": [
      "-UcFeTfm1oM",
      "61ymOWwOwuk",
      "R7M3_9NOA7o",
      "KfgdNGl0tv0"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-68",
    "title": "Heartless",
    "artist": "The Weeknd",
    "album": "After Hours",
    "genre": "hiphop",
    "category": "hiphop",
    "duration": 198,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/2b/b9/fe/2bb9fef5-d7f3-8345-25a9-db0e79fde4e4/20UMGIM11048.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/70/14/79/701479a4-bdb2-f415-ff6a-b3233d26f733/mzaf_13658083032622956283.plus.aac.p.m4a",
    "ytVideoId": "-uj9b9JCIJM",
    "ytCandidateIds": [
      "RwnE0xR50ms",
      "1DpH-icPpl0",
      "07VAsrX8zRQ",
      "yFRo5QlW0OU"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-69",
    "title": "Kill Bill",
    "artist": "SZA",
    "album": "SOS",
    "genre": "hiphop",
    "category": "hiphop",
    "duration": 154,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music122/v4/bd/3b/a9/bd3ba9fb-9609-144f-bcfe-ead67b5f6ab3/196589564931.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/45/2b/ea/452bead6-c7f5-82d4-f5f7-ec876014b4cc/mzaf_2905911853279084717.plus.aac.p.m4a",
    "ytVideoId": "SQnc1QibapQ",
    "ytCandidateIds": [
      "muw4wZt57Jg",
      "TsulQZDKM-g",
      "KGBZyJxu6wM",
      "1k6y7ORleFE"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-70",
    "title": "Die For You",
    "artist": "The Weeknd",
    "album": "Starboy",
    "genre": "hiphop",
    "category": "hiphop",
    "duration": 260,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/e2/61/f8/e261f8c1-73db-9a7a-c89e-1068f19970e0/16UMGIM67863.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/50/50/1a/50501a86-bd74-e90d-8a56-68c9b5e6e7d6/mzaf_4588197682084244913.plus.aac.p.m4a",
    "ytVideoId": "2AH5l-vrY9Q",
    "ytCandidateIds": [
      "RpyN9pFXUCg",
      "QLCpqdqeoII",
      "yka6mulGMmU",
      "YQ-qToZUybM"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-71",
    "title": "Golden Hour",
    "artist": "JVKE",
    "album": "this is what ____ feels like",
    "genre": "lofi",
    "category": "chill",
    "duration": 209,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music211/v4/8d/1a/7b/8d1a7b44-316f-7c7f-4380-935673fb697a/5056167175650.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/30/02/8c/30028c8a-a125-5466-bcc6-27a83b1c0135/mzaf_16911571635366913039.plus.aac.p.m4a",
    "ytVideoId": "PEM0Vs8jf1w",
    "ytCandidateIds": [
      "jYEp86vn9EM",
      "UsR08cY8k0A",
      "8XZ7dKan--4",
      "xEBtv1QkIeM"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-72",
    "title": "death bed (coffee for your head)",
    "artist": "Powfu, beabadoobee",
    "album": "poems of the past",
    "genre": "lofi",
    "category": "chill",
    "duration": 173,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/58/60/43/58604376-4479-9814-1d3b-61d796ee1be9/886448465140.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/51/34/00/51340045-8035-1b5c-457f-5e49ab253506/mzaf_580442320445066029.plus.aac.p.m4a",
    "ytVideoId": "jJPMnTXl63E",
    "ytCandidateIds": [
      "4N-WFXpBjpc",
      "YJET8KicY9g",
      "hNqdxGsbQsA",
      "Wd5HZJv0eu4"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-73",
    "title": "Sunday Best",
    "artist": "Surfaces",
    "album": "Where the Light Is",
    "genre": "lofi",
    "category": "chill",
    "duration": 159,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/ed/cd/ee/edcdeef4-bc7c-a53d-7e2c-64c158c9a89a/842812115431.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/19/5d/c8/195dc887-0272-4ba1-4cb3-7f6216d102cc/mzaf_16366333469501790932.plus.aac.p.m4a",
    "ytVideoId": "Xt3m04Tscc8",
    "ytCandidateIds": [
      "YFOevF9lycs",
      "lyIhRNPCNiw",
      "_83KqwEEGw4",
      "c41b9xYoMuE"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-74",
    "title": "Snooze",
    "artist": "SZA",
    "album": "SOS",
    "genre": "lofi",
    "category": "chill",
    "duration": 202,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music122/v4/62/93/13/6293132e-20ff-67ab-3d1f-96bb6797a6ba/196589564955.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/b3/9b/ca/b39bca57-2627-1aec-77af-cbf551205394/mzaf_4430383240210492712.plus.aac.p.m4a",
    "ytVideoId": "Sv5yCzPCkv8",
    "ytCandidateIds": [
      "MtUefXEQRAY",
      "CBx6e9cZlBQ",
      "5SpWqlgbdcs",
      "LDY_XyxBu8A"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-75",
    "title": "Location",
    "artist": "Khalid",
    "album": "American Teen",
    "genre": "lofi",
    "category": "chill",
    "duration": 219,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/f8/45/5a/f8455a71-8307-aa9a-9c95-3d22efe0804f/886446326146.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/8e/f8/66/8ef866e9-5d33-1f6d-3ce6-7d7f8a060c41/mzaf_4830540290440739615.plus.aac.p.m4a",
    "ytVideoId": "j0bbRsa-Y9E",
    "ytCandidateIds": [
      "QHpzBKT7DJc",
      "by3yRdlQvzs",
      "qkW88_fOD2s",
      "u4wHP_1twgE"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-76",
    "title": "Riptide",
    "artist": "Vance Joy",
    "album": "Dream Your Life Away",
    "genre": "lofi",
    "category": "chill",
    "duration": 202,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/7a/1c/65/7a1c6571-34e9-bb77-32be-90c72ba003c0/075679920355.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/1e/de/ea/1edeea50-c0f4-9d95-f0b8-b23a1af561db/mzaf_6343110017276582270.plus.aac.p.m4a",
    "ytVideoId": "Y6TFSTHUxi0",
    "ytCandidateIds": [
      "TL_oroU9eN8",
      "lYoWuaw5nSk",
      "uJ_1HMAGb4k",
      "xBIW5IukSsI"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-77",
    "title": "Let Her Go",
    "artist": "Passenger",
    "album": "All the Little Lights",
    "genre": "lofi",
    "category": "chill",
    "duration": 253,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music126/v4/9b/7e/28/9b7e2896-e049-1663-6791-e0111690ffc1/067003051361.png/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/26/90/0f/26900f61-d88a-a558-6f4d-b0dec8ba5262/mzaf_6952636564970959693.plus.aac.p.m4a",
    "ytVideoId": "fO8IN5W87ws",
    "ytCandidateIds": [
      "lRVTVB94zTg",
      "RBumgq5yVrA",
      "JLdjXD_QfU0",
      "dIfcyGCgsbI"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-78",
    "title": "I'm Yours",
    "artist": "Jason Mraz",
    "album": "We Sing. We Dance. We Steal Things.",
    "genre": "lofi",
    "category": "chill",
    "duration": 243,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/f8/ac/ec/f8acec21-40e2-fa91-fe61-1be3cbc1467a/mzi.jokpbtnf.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/63/7d/21/637d21cb-2e4b-a845-bd85-fb327e04464a/mzaf_14367811252980822947.plus.aac.p.m4a",
    "ytVideoId": "dNOz_LUH770",
    "ytCandidateIds": [
      "hxTopOuj01k",
      "w5qOYi41WiA",
      "7tgTIazyErs",
      "EkHTsc9PU2A"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-79",
    "title": "Photograph",
    "artist": "Ed Sheeran",
    "album": "x",
    "genre": "lofi",
    "category": "chill",
    "duration": 259,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/2d/36/f9/2d36f9a7-2c3e-ce0f-7fb6-036feecb221f/825646974450.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/11/4f/6a/114f6ad0-165c-1e3c-8fbd-df4707d7ae26/mzaf_12480083080052535279.plus.aac.p.m4a",
    "ytVideoId": "KKQl-pIRQMY",
    "ytCandidateIds": [
      "HpphFd_mzXE",
      "nSDgHBxUbVQ",
      "zLCL_Y-XT8s",
      "jDUYWjf-2kQ"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-80",
    "title": "Thinking Out Loud",
    "artist": "Ed Sheeran",
    "album": "x",
    "genre": "lofi",
    "category": "chill",
    "duration": 282,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/2d/36/f9/2d36f9a7-2c3e-ce0f-7fb6-036feecb221f/825646974450.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/78/a5/f2/78a5f25e-ad1b-718d-82ad-b82e676c1855/mzaf_6133970271589343093.plus.aac.p.m4a",
    "ytVideoId": "Q5z6RHIpi2Y",
    "ytCandidateIds": [
      "WpyfrixXBqU",
      "wFlRmc5M4bg",
      "XMPgVZtADtQ",
      "lp-EO5I60KA"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-81",
    "title": "Heather",
    "artist": "Conan Gray",
    "album": "Kid Krow",
    "genre": "lofi",
    "category": "chill",
    "duration": 240,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music221/v4/95/a8/2c/95a82c4a-6d4d-2bcb-b3ea-be59a5100e0c/25UMGIM46919.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/fa/7a/94/fa7a94fb-03b6-57e9-d2fd-ad7113509003/mzaf_9701884248345206346.plus.aac.p.m4a",
    "ytVideoId": "GPUg7n8-M6o",
    "ytCandidateIds": [
      "24u3NoPvgMw",
      "izge-rLlINE",
      "0CjfkEmaC4E",
      "VOD9tM20aBM"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-82",
    "title": "Until I Found You",
    "artist": "Stephen Sanchez",
    "album": "Easy On My Eyes",
    "genre": "lofi",
    "category": "chill",
    "duration": 178,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/64/d2/c5/64d2c511-67f4-ae09-5153-d39c3da413a3/21UMGIM75467.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/53/82/c1/5382c1d4-ddba-aa2b-90df-57268895fac9/mzaf_8926201202931541051.plus.aac.p.m4a",
    "ytVideoId": "GxldQ9eX2wo",
    "ytCandidateIds": [
      "GhQxrCrVSyw",
      "kPlSyYtE63M",
      "MlThQTo6D8A",
      "tWkUTPj1BT8"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-83",
    "title": "Romantic Homicide",
    "artist": "d4vd",
    "album": "Petals to Thorns",
    "genre": "lofi",
    "category": "chill",
    "duration": 133,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music112/v4/4e/0c/82/4e0c82e8-7970-25f5-bfd6-6f0faec83dcb/22UMGIM94151.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/a1/f5/40/a1f5405d-408f-d84e-1775-b87b30174067/mzaf_5384372198207712281.plus.aac.p.m4a",
    "ytVideoId": "FpO31FVxxb4",
    "ytCandidateIds": [
      "83MOqrzeF4E",
      "eKL3TceSxvk",
      "Pc9dzQojbCw",
      "xrJO8cXtzEs"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-84",
    "title": "Here With Me",
    "artist": "d4vd",
    "album": "Petals to Thorns",
    "genre": "lofi",
    "category": "chill",
    "duration": 242,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music221/v4/d6/83/1a/d6831a94-4e8f-5b23-df44-a313eb358257/23UMGIM33457.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/bf/a3/6d/bfa36d9c-8e41-e05f-8a2b-970c9b21c695/mzaf_9987737564511061938.plus.aac.p.m4a",
    "ytVideoId": "B7Y4LHbpXv0",
    "ytCandidateIds": [
      "bY4kEuki5hM",
      "Ip6cw8gfHHI",
      "JRipNfX7ahQ",
      "CL7sR2rOXt0"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-85",
    "title": "Glimpse of Us",
    "artist": "Joji",
    "album": "SMITHEREENS",
    "genre": "lofi",
    "category": "chill",
    "duration": 233,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music221/v4/d0/2a/43/d02a433a-3ab8-9a94-b07d-1dc599b64966/93624864387.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/0c/53/c2/0c53c240-300a-5ddf-fc86-3a54e1b73a78/mzaf_13555682862214742934.plus.aac.p.m4a",
    "ytVideoId": "FvOpPeKSf_4",
    "ytCandidateIds": [
      "_x3UltzBxjw",
      "NgsWGfUlwJI",
      "xuGaLIleROI",
      "lVpTSJzrD3o"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-86",
    "title": "Yellow",
    "artist": "Coldplay",
    "album": "Parachutes",
    "genre": "rock",
    "category": "classics",
    "duration": 269,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music221/v4/f5/93/8c/f5938c49-964c-31d1-4b33-78b634f71fb7/190295978075.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/66/f3/1a/66f31a76-a6ed-cb4c-f353-23310a7ae9a8/mzaf_10593596652344378873.plus.aac.p.m4a",
    "ytVideoId": "tdVAqxNLXiw",
    "ytCandidateIds": [
      "yKNxeF4KMsY",
      "q7mlB-adMBc",
      "vsSrzSuEHS4",
      "O70-xOKIxMs"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-87",
    "title": "Viva La Vida",
    "artist": "Coldplay",
    "album": "Viva La Vida",
    "genre": "rock",
    "category": "classics",
    "duration": 241,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/52/aa/85/52aa851f-15b7-6322-f91f-df84b15b7b19/190295978044.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/a3/30/8e/a3308eed-d8b7-e0b3-f09d-5e1b0f4d660a/mzaf_8517946447501075134.plus.aac.p.m4a",
    "ytVideoId": "dvgZkm1xWPE",
    "ytCandidateIds": [
      "y4zdDXPYo0I",
      "Rihdz-5_VmY",
      "vwdNAhdgHWA",
      "FKRhAk5VmGw"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-88",
    "title": "Bohemian Rhapsody",
    "artist": "Queen",
    "album": "A Night at the Opera",
    "genre": "rock",
    "category": "classics",
    "duration": 354,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music211/v4/8b/0a/ea/8b0aea60-6f4a-195b-5958-cdf459c2333b/602527644271.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/4b/83/09/4b8309c3-e3b2-10bd-ea80-ec017d832503/mzaf_9752264660400108875.plus.aac.p.m4a",
    "ytVideoId": "xG16sdjLtc0",
    "ytCandidateIds": [
      "fJ9rUzIMcZQ",
      "GR1G2rl8GGY",
      "0dJ00UKYYyc",
      "NNyMIqagkfM"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-89",
    "title": "Counting Stars",
    "artist": "OneRepublic",
    "album": "Native",
    "genre": "rock",
    "category": "classics",
    "duration": 257,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music126/v4/25/46/a7/2546a71a-b2bb-b4c9-4c52-a4daa3ae23ca/13UMGIM15076.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/b0/db/7f/b0db7fbe-f8ff-1f67-fe72-ca8185ffbca2/mzaf_15298650366584767800.plus.aac.p.m4a",
    "ytVideoId": "4WgWGcED0JQ",
    "ytCandidateIds": [
      "mgT0N3tMP74",
      "wv8vq83A7ZQ",
      "hT_nvWreIhg",
      "uG5toppE3qI"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-90",
    "title": "Demons",
    "artist": "Imagine Dragons",
    "album": "Night Visions",
    "genre": "rock",
    "category": "classics",
    "duration": 178,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music112/v4/1f/fa/09/1ffa092f-f52f-4a66-7d10-4cc5982dc747/12UMGIM46901.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/fc/d4/e8/fcd4e814-39f4-19e8-f421-c2d269698025/mzaf_1039703479531920971.plus.aac.p.m4a",
    "ytVideoId": "pvrkfb1C4tE",
    "ytCandidateIds": [
      "MA0aCUxItYA",
      "LqI78S14Wgg",
      "mWRsgZuwf_8",
      "56U1OI0rI0w"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-91",
    "title": "Radioactive",
    "artist": "Imagine Dragons",
    "album": "Night Visions",
    "genre": "rock",
    "category": "classics",
    "duration": 187,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music112/v4/1f/fa/09/1ffa092f-f52f-4a66-7d10-4cc5982dc747/12UMGIM46901.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/77/70/88/777088e9-60a1-c459-bfa5-6e66f2fd2695/mzaf_7685408661765681881.plus.aac.p.m4a",
    "ytVideoId": "w3viBe2Q0P8",
    "ytCandidateIds": [
      "CAEUnn0HNLM",
      "ktvTqknDobU",
      "e08lOBTqJz4",
      "tVdJLqFZ1xc"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-92",
    "title": "In The End",
    "artist": "Linkin Park",
    "album": "Hybrid Theory",
    "genre": "rock",
    "category": "classics",
    "duration": 216,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/53/a7/7f/53a77fab-c54c-a57b-8130-248fc12d0c80/093624948995.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/d9/33/34/d933341d-ba95-dc3b-11a3-34d6632dd62e/mzaf_10942671303595386057.plus.aac.p.m4a",
    "ytVideoId": "gB9P0kpc1O4",
    "ytCandidateIds": [
      "Q3gy8A0jY10",
      "g9j5UzxEhEM",
      "eVTXPUF4Oz4",
      "-mZURD3LAW0"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-93",
    "title": "Numb",
    "artist": "Linkin Park",
    "album": "Meteora",
    "genre": "rock",
    "category": "classics",
    "duration": 188,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/13/44/05/134405bd-9e27-a678-8953-b5f724201f95/093624948988.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/1f/9d/28/1f9d2810-2ac3-efbd-ef02-623691ff9cd2/mzaf_17560018091772095942.plus.aac.p.m4a",
    "ytVideoId": "vuFdq_jWeko",
    "ytCandidateIds": [
      "KIfYtDl4B2g",
      "kXYiU_JCYtU",
      "XF1LGG6nCKg",
      "IVWE4JiONSw"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-94",
    "title": "Smells Like Teen Spirit",
    "artist": "Nirvana",
    "album": "Nevermind",
    "genre": "rock",
    "category": "classics",
    "duration": 301,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/95/fd/b9/95fdb9b2-6d2b-92a6-97f2-51c1a6d77f1a/00602527874609.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/65/49/4e/65494e02-b6d3-26d8-6b0c-9bd98dcf4d5d/mzaf_7665413316386155700.plus.aac.p.m4a",
    "ytVideoId": "69Wqhhun5_o",
    "ytCandidateIds": [
      "hTWKbfoikeg",
      "JyGNABrosb8",
      "q8sGURLcGK4",
      "Q6SHkQMFVlc"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-95",
    "title": "Sweet Child O' Mine",
    "artist": "Guns N' Roses",
    "album": "Appetite for Destruction",
    "genre": "rock",
    "category": "classics",
    "duration": 356,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/56/47/b7/5647b700-6b9d-9e72-ec9f-51140b6d4492/00602567673781.rgb.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/0d/cb/f3/0dcbf381-7cbf-78b8-7f74-d5789adf65a1/mzaf_17081805577020235844.plus.aac.p.m4a",
    "ytVideoId": "aEMool3DlIU",
    "ytCandidateIds": [
      "D2gWc5Sw75w",
      "qoflJn7zkFM",
      "1w7OgIMMRc4",
      "6HSMmIgy1Eg"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-96",
    "title": "Hotel California",
    "artist": "Eagles",
    "album": "Hotel California",
    "genre": "rock",
    "category": "classics",
    "duration": 391,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/88/16/2c/88162c3d-46db-8321-61f3-3a47404cfe76/075596050920.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/17/30/06/1730066d-13fb-6803-0e52-46d4762b94e0/mzaf_8068080726527063383.plus.aac.p.m4a",
    "ytVideoId": "dLl4PZtxia8",
    "ytCandidateIds": [
      "BciS5krYL80",
      "09839DpTctU",
      "8rX4LjZ3Oo4",
      "4FGrB3u9BjU"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-97",
    "title": "Wonderwall",
    "artist": "Oasis",
    "album": "(What's the Story) Morning Glory?",
    "genre": "rock",
    "category": "classics",
    "duration": 259,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music113/v4/04/92/e0/0492e08b-cbcc-9969-9ad6-8f5a0888068c/5051961007107.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/ab/16/93/ab16933c-6203-3db9-9da9-513ff1c8496d/mzaf_16993612140334549994.plus.aac.p.m4a",
    "ytVideoId": "FVdjZYfDuLE",
    "ytCandidateIds": [
      "bx1Bh8ZvH84",
      "PoJh4JNedns",
      "8LaTzWMbShY",
      "uGcrbDOK2SQ"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-98",
    "title": "Don't Stop Believin'",
    "artist": "Journey",
    "album": "Escape",
    "genre": "rock",
    "category": "classics",
    "duration": 251,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/71/2d/61/712d617d-f4a4-5904-1b11-d4b4b45c47c5/828768588925.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/0f/e9/54/0fe95410-dc38-8696-0259-f61d869e9fca/mzaf_13616088119456591905.plus.aac.p.m4a",
    "ytVideoId": "1k8craCGpgs",
    "ytCandidateIds": [
      "Pze8Dyqiky8",
      "jidZEUOR6zs",
      "PIFUWHvSixw",
      "VcjzHMhBtf0"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-99",
    "title": "The Scientist",
    "artist": "Coldplay",
    "album": "A Rush of Blood to the Head",
    "genre": "rock",
    "category": "classics",
    "duration": 309,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/b9/b4/2a/b9b42ad1-1e25-5096-da43-497a247e69a3/190295978051.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/ae/a6/27/aea62715-e6ae-9562-ba81-1f969a2ee2fa/mzaf_9054259057357054559.plus.aac.p.m4a",
    "ytVideoId": "zVyvpladEms",
    "ytCandidateIds": [
      "c1VNAUqwREY",
      "RB-RcX5DS5A",
      "QSVfXaFNFho",
      "m7-HR6nzpeE"
    ],
    "resolvedFull": true,
    "preview": false
  },
  {
    "id": "track-100",
    "title": "Something Just Like This",
    "artist": "The Chainsmokers, Coldplay",
    "album": "Memories...Do Not Open",
    "genre": "rock",
    "category": "classics",
    "duration": 247,
    "cover": "https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/9d/56/6f/9d566f55-5253-bed6-5c31-df952dae649d/886446379289.jpg/600x600bb.jpg",
    "streamUrl": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/64/7f/96/647f9601-aa94-3599-6c73-0143510b8b92/mzaf_13538528720942742126.plus.aac.p.m4a",
    "ytVideoId": "FM7MFYoylVs",
    "ytCandidateIds": [
      "QHCm2vh3jlM",
      "fZUfdnmtg4Y",
      "nwFIp_gaACg",
      "MXJ4TnrL6c4"
    ],
    "resolvedFull": true,
    "preview": false
  }
];

const SPOTIFY_SECTIONS = [
  {
    "id": "tophits",
    "title": "Today's Top Hits",
    "subtitle": "The hottest tracks on the planet right now",
    "tag": "Billboard Hot 100",
    "genre": "pop"
  },
  {
    "id": "charts",
    "title": "Global Chart Toppers",
    "subtitle": "Record-breaking anthems with billions of plays",
    "tag": "Global 50",
    "genre": "synthwave"
  },
  {
    "id": "pop",
    "title": "Pop & Dance Anthems",
    "subtitle": "High energy chart-toppers to power your day",
    "tag": "Party",
    "genre": "pop"
  },
  {
    "id": "hiphop",
    "title": "Hip-Hop & Late Night R&B",
    "subtitle": "Heavy bass, midnight mood tracks and global trap",
    "tag": "Late Night",
    "genre": "hiphop"
  },
  {
    "id": "chill",
    "title": "Chill Lo-Fi & Coffee Beats",
    "subtitle": "Relax, study and unwind with smooth laidback melodies",
    "tag": "Relaxing",
    "genre": "lofi"
  },
  {
    "id": "classics",
    "title": "Rock & Timeless Classics",
    "subtitle": "Legendary stadium anthems that live forever",
    "tag": "Legendary",
    "genre": "rock"
  }
];

if (typeof module !== 'undefined') {
  module.exports = { CURATED_TRACKS, SPOTIFY_SECTIONS };
}
